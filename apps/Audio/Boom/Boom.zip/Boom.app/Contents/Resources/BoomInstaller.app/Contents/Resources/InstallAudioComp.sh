#!/bin/sh

FILE_PATH=$1
mkdir -p ~/Library/Audio/Plug-Ins/Components
chmod -R 777 ~/Library/Audio/Plug-Ins/Components
cp -rv $FILE_PATH ~/Library/Audio/Plug-Ins/Components
