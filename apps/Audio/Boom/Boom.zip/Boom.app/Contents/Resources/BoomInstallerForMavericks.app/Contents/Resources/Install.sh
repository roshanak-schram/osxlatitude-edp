#!/bin/sh

FILE_PATH=$1

if sudo kextunload  /System/Library/Extensions/BoomDevice.kext
	then
	echo "kextunload succeeded" >> ~/Library/Logs/Boom.log
else
	echo "kextunload failed" >> ~/Library/Logs/Boom.log
fi
if sudo kextunload -b com.globaldelight.driver.BoomDevice
then
echo "kextunload succeeded" >> ~/Library/Logs/Boom.log
else
echo "kextunload failed" >> ~/Library/Logs/Boom.log
fi
if sudo rm -rv /System/Library/Extensions/BoomDevice.kext
	then
	echo "Remove BoomDevice Kext succeeded" >> ~/Library/Logs/Boom.log
else
	echo "Remove BoomDevice Kext failed" >> ~/Library/Logs/Boom.log
fi

if sudo cp -rv $FILE_PATH /System/Library/Extensions
	then
	echo "Copy BoomDevice Kext succeeded" >> ~/Library/Logs/Boom.log
else
	echo "Copy BoomDevice Kext failed" >> ~/Library/Logs/Boom.log
fi

if sudo chown -R root:wheel /System/Library/Extensions/BoomDevice.kext
	then
	echo "chown BoomDevice Kext succeeded" >> ~/Library/Logs/Boom.log
else
	echo "chown BoomDevice Kext failed" >> ~/Library/Logs/Boom.log
fi

if sudo chmod -R 755 /System/Library/Extensions/BoomDevice.kext
	then
	echo "chmod BoomDevice Kext succeeded" >> ~/Library/Logs/Boom.log
else
	echo "chmod BoomDevice Kext failed" >> ~/Library/Logs/Boom.log
fi

if sudo kextload /System/Library/Extensions/BoomDevice.kext
	then
	echo "kextload BoomDevice Kext succeeded" >> ~/Library/Logs/Boom.log
else
	echo "kextload BoomDevice Kext failed" >> ~/Library/Logs/Boom.log
fi

echo "Whether kext is loaded ***" >> ~/Library/Logs/Boom.log

sudo kextstat | grep Boom >> ~~/Library/Logs/Boom.log

if sudo touch /System/Library/Extensions
	then
	echo "touch BoomDevice Kext succeeded" >> ~/Library/Logs/Boom.log
else
	echo "touch BoomDevice Kext failed" >> ~/Library/Logs/Boom.log
fi

if sudo touch /private/var/db/.AccessibilityAPIEnabled
	then
	echo "Enable Universal access succeeded" >> ~/Library/Logs/Boom.log
else
	echo "Enable Universal access failed" >> ~/Library/Logs/Boom.log
fi