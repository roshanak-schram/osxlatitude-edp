#!/bin/sh

FILE_PATH=$1
kextunload /System/Library/Extensions/BoomDevice.kext
rm -rv /System/Library/Extensions/BoomDevice.kext
cp -rv $FILE_PATH /System/Library/Extensions
chown -R root:wheel /System/Library/Extensions/BoomDevice.kext
chmod -R 755 /System/Library/Extensions/BoomDevice.kext
kextload /System/Library/Extensions/BoomDevice.kext

touch /System/Library/Extensions
rm -rv /Library/Audio/Plug-Ins/Components/VolumeBooster.component

touch /private/var/db/.AccessibilityAPIEnabled
